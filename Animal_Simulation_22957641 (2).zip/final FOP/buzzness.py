import random
import numpy as np

class Bee:
    def __init__(self, ID, pos):
        self.ID = ID
        self.pos = pos
        self.age = 0
        self.inhive = True
        self.nectar_collected = 0
        

    def step_change1(self, worldX, worldY, hiveX, hiveY, timestep):
        if self.inhive:
            leave_chance = timestep / 5.0
            if random.random() < leave_chance:
                self.inhive = False
                self.pos = (random.randint(0, worldX - 1), random.randint(0, worldY - 1))
        else:
            validmoves = [(1,0), (-1,0), (0,1), (0,-1),
                          (1,1), (1,-1), (-1,1), (-1,-1), (0,0)]
            move = random.choice(validmoves)
            new_x = max(0, min(self.pos[0] + move[0], worldX - 1))
            new_y = max(0, min(self.pos[1] + move[1], worldY - 1))
            self.pos = (new_x, new_y)

    def move_towards_flower(self, flower_positions):
        if not flower_positions:
            return
        target = random.choice(flower_positions)
        dx = np.sign(target[0] - self.pos[0])
        dy = np.sign(target[1] - self.pos[1]) 
        self.pos = (self.pos[0] + dx, self.pos[1] + dy)

    def move_towards_tree(self, tree_positions):
        if not tree_positions:
            return
        target = random.choice(tree_positions)
        dx = np.sign(target[0] - self.pos[0]) 
        dy = np.sign(target[1] - self.pos[1]) 
        self.pos = (self.pos[0] + dx, self.pos[1] + dy)

    def move_out_of_tree(self, worldX, worldY):
        validmoves = [(1,0), (-1,0), (0,1), (0,-1),
                      (1,1), (1,-1), (-1,1), (-1,-1), (0,0)]
        move = random.choice(validmoves)
        new_x = max(0, min(self.pos[0] + move[0], worldX - 1))
        new_y = max(0, min(self.pos[1] + move[1], worldY - 1))
        self.pos = (new_x, new_y)

    def get_pos(self):
        return self.pos

    def set_pos(self, new_pos):
        self.pos = new_pos

    def get_inhive(self):
        return self.inhive

    def set_inhive(self, value):
        self.inhive = value

class Bat:
    def __init__(self, ID, pos):
        self.ID = ID
        self.pos = pos
        self.age = 0
        self.inhive = True
        self.nectar_collected = 0
        

    def step_change1(self, worldX, worldY, hiveX, hiveY, timestep):
        if self.inhive:
            leave_chance = timestep / 5.0
            if random.random() < leave_chance:
                self.inhive = False
                self.pos = (random.randint(0, worldX - 1), random.randint(0, worldY - 1))
        else:
            validmoves = [(1,0), (-1,0), (0,1), (0,-1),
                          (1,1), (1,-1), (-1,1), (-1,-1), (0,0)]
            move = random.choice(validmoves)
            new_x = max(0, min(self.pos[0] + move[0], worldX - 1))
            new_y = max(0, min(self.pos[1] + move[1], worldY - 1))
            self.pos = (new_x, new_y)

    def move_towards_flower(self, flower_positions):
        if not flower_positions:
            return
        target = random.choice(flower_positions)
        dx = np.sign(target[0] - self.pos[0]) 
        dy = np.sign(target[1] - self.pos[1]) 
        self.pos = (self.pos[0] + dx, self.pos[1] + dy)

    def move_towards_tree(self, tree_positions):
        if not tree_positions:
            return
        target = random.choice(tree_positions)
        dx = np.sign(target[0] - self.pos[0]) 
        dy = np.sign(target[1] - self.pos[1])
        self.pos = (self.pos[0] + dx, self.pos[1] + dy)

    def move_out_of_tree(self, worldX, worldY):
        validmoves = [(1,0), (-1,0), (0,1), (0,-1),
                      (1,1), (1,-1), (-1,1), (-1,-1), (0,0)]
        move = random.choice(validmoves)
        new_x = max(0, min(self.pos[0] + move[0], worldX - 1))
        new_y = max(0, min(self.pos[1] + move[1], worldY - 1))
        self.pos = (new_x, new_y)

    def get_pos(self):
        return self.pos

    def set_pos(self, new_pos):
        self.pos = new_pos

    def get_inhive(self):
        return self.inhive

    def set_inhive(self, value):
        self.inhive = value

class Butterfly:
    def __init__(self, ID, pos):
        self.ID = ID
        self.pos = pos
        self.age = 0
        self.inhive = True
        self.nectar_collected = 0
        

    def step_change1(self, worldX, worldY, hiveX, hiveY, timestep):
        if self.inhive:
            leave_chance = timestep / 5.0
            if random.random() < leave_chance:
                self.inhive = False
                self.pos = (random.randint(0, worldX - 1), random.randint(0, worldY - 1))
        else:
            validmoves = [(1,0), (-1,0), (0,1), (0,-1),
                          (1,1), (1,-1), (-1,1), (-1,-1), (0,0)]
            move = random.choice(validmoves)
            new_x = max(0, min(self.pos[0] + move[0], worldX - 1))
            new_y = max(0, min(self.pos[1] + move[1], worldY - 1))
            self.pos = (new_x, new_y)

    def move_towards_flower(self, flower_positions):
        if not flower_positions:
            return
        target = random.choice(flower_positions)
        dx = np.sign(target[0] - self.pos[0])
        dy = np.sign(target[1] - self.pos[1]) 
        self.pos = (self.pos[0] + dx, self.pos[1] + dy)

    def move_towards_tree(self, tree_positions):
        if not tree_positions:
            return
        target = random.choice(tree_positions)
        dx = np.sign(target[0] - self.pos[0]) 
        dy = np.sign(target[1] - self.pos[1])
        self.pos = (self.pos[0] + dx, self.pos[1] + dy)

    def move_out_of_tree(self, worldX, worldY):
        validmoves = [(1,0), (-1,0), (0,1), (0,-1),
                      (1,1), (1,-1), (-1,1), (-1,-1), (0,0)]
        move = random.choice(validmoves)
        new_x = max(0, min(self.pos[0] + move[0], worldX - 1))
        new_y = max(0, min(self.pos[1] + move[1], worldY - 1))
        self.pos = (new_x, new_y)

    def get_pos(self):
        return self.pos

    def set_pos(self, new_pos):
        self.pos = new_pos

    def get_inhive(self):
        return self.inhive

    def set_inhive(self, value):
        self.inhive = value

class Flower:
    def __init__(self, pos, nectar_amount=5):
        self.pos = pos
        self.nectar_amount = nectar_amount

    def give_nectar(self):
        if self.nectar_amount > 0:
            collected = self.nectar_amount
            self.nectar_amount = 0
            return collected
        return 0

class Tree:
    def __init__(self, pos, nectar_amount=5):
        self.pos = pos
        self.nectar_amount = nectar_amount

    def give_nectar(self):
        if self.nectar_amount > 0:
            collected = self.nectar_amount
            self.nectar_amount = 0
            return collected
        return 0
