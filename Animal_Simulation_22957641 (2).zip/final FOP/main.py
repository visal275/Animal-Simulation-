import matplotlib.pyplot as plt
import numpy as np
import random
import sys
import csv
from datetime import datetime
from buzzness import Bee, Bat, Butterfly, Flower, Tree

# World and hive dimensions
worldX, worldY = 50, 41
hiveX, hiveY = 30, 25
hive_pos = (35, 25)

# Example honey sharing spots
honey_sharing_spots = [(15, 15), (16, 15), (17, 15)]

def run_batch_simulation(name, animal_type, animal_count, flower_count, tree_count, mode, intensity, sim_length):
    print(f"\nRunning simulation for {name} with {animal_count} {animal_type}, {flower_count} flowers, and {tree_count} trees in {mode} mode with intensity {intensity}...\n")

    # Run the simulation
    run_simulation(animal_type, animal_count, flower_count, tree_count, mode, intensity, sim_length)

def interactive_mode():
    print("=== Interactive AnimalWorld Mode ===")
    name = input("Enter your name: ")

    animal_type = input("Choose animal type (Bees/Bats/Butterflies): ").capitalize()
    while animal_type not in ["Bees", "Bats", "Butterflies"]:
        print("Invalid animal type. Please choose either 'Bees', 'Bats', or 'Butterflies'.")
        animal_type = input("Choose animal type (Bees/Bats/Butterflies): ").capitalize()

    valid_input = False
    while not valid_input:
        try:
            num_animals = int(input(f"Enter the number of {animal_type} (10-50): "))
            if 10 <= num_animals <= 50:
                animal_count = num_animals
                valid_input = True
            else:
                print("Please enter a number between 10 and 50.")
        except ValueError:
            print("Invalid input. Please enter an integer.")

    valid_input = False
    while not valid_input:
        try:
            num_flowers = int(input("Enter the number of flowers (1-10): "))
            if 1 <= num_flowers <= 10:
                flower_count = num_flowers
                valid_input = True
            else:
                print("Please enter a number between 1 and 10.")
        except ValueError:
            print("Invalid input. Please enter an integer.")

    valid_input = False
    while not valid_input:
        try:
            num_trees = int(input("Enter the number of trees (1-10): "))
            if 1 <= num_trees <= 10:
                tree_count = num_trees
                valid_input = True
            else:
                print("Please enter a number between 1 and 10.")
        except ValueError:
            print("Invalid input. Please enter an integer.")

    mode = input("Choose mode (day/night): ").lower()
    while mode not in ["day", "night"]:
        print("Invalid mode. Please choose either 'day' or 'night'.")
        mode = input("Choose mode (day/night): ").lower()

    intensity = input("Choose intensity (light/medium/heavy): ").lower()
    while intensity not in ["light", "medium", "heavy"]:
        print("Invalid intensity. Please choose either 'light', 'medium', or 'heavy'.")
        intensity = input("Choose intensity (light/medium/heavy): ").lower()

    valid_input = False
    while not valid_input:
        try:
            sim_length = int(input("Enter the simulation length (10-100): "))
            if 10 <= sim_length <= 100:
                valid_input = True
            else:
                print("Please enter a number between 10 and 100.")
        except ValueError:
            print("Invalid input. Please enter an integer.")

    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open("data.csv", "w", newline="") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["Name", "AnimalType", "AnimalCount", "FlowerCount", "TreeCount", "Mode", "Intensity", "SimLength", "Time"])
        writer.writerow([name, animal_type, animal_count, flower_count, tree_count, mode, intensity, sim_length, current_time])

    print(f"Saved '{animal_count}' {animal_type}, '{flower_count}' flowers, and '{tree_count}' trees for user '{name}' to data.csv at {current_time}.")

    # Run the simulation
    run_simulation(animal_type, animal_count, flower_count, tree_count, mode, intensity, sim_length)

def read_para_file(para_file_path):
    try:
        with open(para_file_path, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                name = row['Name']
                animal_type = row['AnimalType']
                animal_count = int(row['AnimalCount'])
                flower_count = int(row['FlowerCount'])
                tree_count = int(row['TreeCount'])
                mode = row['Mode']
                intensity = row['Intensity']
                sim_length = int(row['SimLength'])
                time = datetime.strptime(row['Time'], '%Y-%m-%d %H:%M:%S')

                print(f"Read from para.csv: Name={name}, AnimalType={animal_type}, AnimalCount={animal_count}, FlowerCount={flower_count}, TreeCount={tree_count}, Mode={mode}, Intensity={intensity}, SimLength={sim_length}, Time={time}")
                return name, animal_type, animal_count, flower_count, tree_count, mode, intensity, sim_length, time
    except FileNotFoundError:
        print(f"Error: The file '{para_file_path}' does not exist.")
    except Exception as e:
        print(f"Error reading parameter file: {e}")

# World grid setup
world = np.full((worldX, worldY), 6)
world[20:21, 20:21] = 18
world[10:16, 30:36] = 13
world[30:41, 5:11] = 1

for x in range(25, 50):
    for y in range(20, 41):
        world[x, y] = 7 if (x % 2 == 0 and y % 2 == 0) else 6

world[5, 17] = 4
world[10, 17] = 4

# Tree grid setup
for x in range(2, 9, 2):
    world[x, 5:10] = 5

# Hive grid setup
hive = np.full((hiveX, hiveY), 10)
mid_x = hiveX // 2
for y in range(hiveY):
    hive[mid_x - 1, y] = 5
    hive[mid_x + 1, y] = 5
    hive[mid_x, y] = 7 if y % 2 == 0 else 5

def plot_hive(hive, alist, ax, timestep, mode="day"):
    ax.clear()  # Clear the previous plot
    xvalues = [a.get_pos()[0] for a in alist if a.get_inhive()]
    yvalues = [a.get_pos()[1] for a in alist if a.get_inhive()]
    nectar_values = [a.nectar_collected for a in alist if a.get_inhive()]

    cmap = 'YlOrBr' if mode == "day" else 'Greys'
    ax.imshow(hive.T, origin="lower", cmap=cmap)

    # Assign colors based on animal type
    colors = []
    for a in alist:
        if isinstance(a, Bee):
            colors.append('yellow')
        elif isinstance(a, Bat):
            colors.append('grey')
        elif isinstance(a, Butterfly):
            colors.append('purple')

    ax.scatter(xvalues, yvalues, color=colors[:len(xvalues)])

    for x, y, nectar in zip(xvalues, yvalues, nectar_values):
        ax.text(x + 0.2, y, str(nectar), color='black', fontsize=8)

    ax.set_title(f"Animal Hive - Timestep {timestep}")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")

def plot_world(world, alist, flowers, trees, ax, timestep, total_nectar_collected, mode="day"):
    ax.clear()  # Clear the previous plot
    cmap = 'tab20' if mode == "day" else 'Greys'
    ax.imshow(world.T, origin="lower", cmap=cmap)

    x_animals = [a.get_pos()[0] for a in alist if not a.get_inhive()]
    y_animals = [a.get_pos()[1] for a in alist if not a.get_inhive()]
    nectar_values = [a.nectar_collected for a in alist if not a.get_inhive()]

    # Assign colors based on animal type
    colors = []
    for a in alist:
        if isinstance(a, Bee):
            colors.append('yellow')
        elif isinstance(a, Bat):
            colors.append('grey')
        elif isinstance(a, Butterfly):
            colors.append('purple')

    ax.scatter(x_animals, y_animals, color=colors[:len(x_animals)], label="Animals")

    for x, y, nectar in zip(x_animals, y_animals, nectar_values):
        ax.text(x + 0.2, y, str(nectar), color='white', fontsize=8, weight='bold')

    for flower in flowers:
        fx, fy = flower.pos
        ax.scatter(fx, fy, color='magenta', marker='*', s=200, label="Flower" if flower == flowers[0] else "")
        ax.text(fx, fy + 0.5, str(flower.nectar_amount), color='white', fontsize=8, ha='center')

    for tree in trees:
        tx, ty = tree.pos
        ax.scatter(tx, ty, color='green', marker='^', s=200, label="Tree" if tree == trees[0] else "")
        ax.text(tx, ty + 0.5, str(tree.nectar_amount), color='white', fontsize=8, ha='center')

    ax.set_title(f"World Map - Timestep {timestep}")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.legend(loc="upper right")

    # Display total nectar collected at the top left
    ax.text(0.02, 0.95, f"Total Nectar Collected: {total_nectar_collected}", transform=ax.transAxes, fontsize=12, verticalalignment='top', bbox=dict(boxstyle='round', facecolor='white', alpha=0.5))

def run_simulation(animal_type, animal_count, flower_count, tree_count, mode="day", intensity="light", sim_length=20):
    # Define mid_x within the function
    mid_x = hiveX // 2

    # Create animals at random positions inside hive
    alist = []
    for i in range(animal_count):
        x = np.random.randint(0, hiveX)
        y = np.random.randint(0, hiveY)
        if animal_type == "Bees":
            alist.append(Bee(f"b{i}", (x, y)))
        elif animal_type == "Bats":
            alist.append(Bat(f"b{i}", (x, y)))
        elif animal_type == "Butterflies":
            alist.append(Butterfly(f"b{i}", (x, y)))

    # Create flowers at random positions in the world
    flowers = []
    for i in range(flower_count):
        x = np.random.randint(0, worldX)
        y = np.random.randint(0, worldY)
        flowers.append(Flower(pos=(x, y), nectar_amount=5))

    # Create trees at random positions in the world
    trees = []
    for i in range(tree_count):
        x = np.random.randint(0, worldX)
        y = np.random.randint(0, worldY)
        trees.append(Tree(pos=(x, y), nectar_amount=5))

    # Assign a target (flower or tree) to each animal
    animal_targets = []
    for a in alist:
        if random.random() < 0.5:  # 50% chance to target flowers
            target = random.choice(flowers).pos
        else:  # 50% chance to target trees
            target = random.choice(trees).pos
        animal_targets.append((a, target))

    plt.ion()  # Turn on interactive mode for live plotting
    fig, axes = plt.subplots(1, 2, figsize=(12, 6))

    i = 0  # Used for rotating tree positions
    for t in range(sim_length):
        total_nectar_collected = sum(a.nectar_collected for a in alist)

        for a, target in animal_targets:
            try:
                # Define behavior based on percentage of total simulation length
                if t <= 0.25 * sim_length:  # First 25% of the simulation
                    # Stage 1: Early hive departure
                    a.step_change1(worldX, worldY, hiveX, hiveY, t)
                elif 0.25 * sim_length < t <= 0.35 * sim_length:  # Next 10% of the simulation
                    # Stage 2: Move towards target and collect nectar
                    if not a.get_inhive():
                        a.step_change1(worldX, worldY, hiveX, hiveY, t)
                        dx = np.sign(target[0] - a.get_pos()[0]) 
                        dy = np.sign(target[1] - a.get_pos()[1]) 
                        a.pos = (a.get_pos()[0] + dx, a.get_pos()[1] + dy)

                        # Check if animal reached the target
                        if a.get_pos() == target:
                            if target in [flower.pos for flower in flowers]:
                                for flower in flowers:
                                    if a.get_pos() == flower.pos:
                                        nectar = flower.give_nectar()
                                        if nectar > 0:
                                            a.nectar_collected += nectar
                                            print(f"{animal_type[:-1]} {a.ID} collected {nectar} nectar from flower at {flower.pos} at timestep {t}")
                                        else:
                                            print(f"{animal_type[:-1]} {a.ID} found no nectar at flower {flower.pos} at timestep {t}")
                            elif target in [tree.pos for tree in trees]:
                                for tree in trees:
                                    if a.get_pos() == tree.pos:
                                        nectar = tree.give_nectar()
                                        if nectar > 0:
                                            a.nectar_collected += nectar
                                            print(f"{animal_type[:-1]} {a.ID} collected {nectar} nectar from tree at {tree.pos} at timestep {t}")
                                        else:
                                            print(f"{animal_type[:-1]} {a.ID} found no nectar at tree {tree.pos} at timestep {t}")
                elif 0.35 * sim_length < t <= 0.5 * sim_length:  # Next 15% of the simulation
                    # Stage 3: Animals are directly placed on targets and collect nectar
                    if not a.get_inhive():
                        a.pos = target
                        if target in [flower.pos for flower in flowers]:
                            for flower in flowers:
                                if a.get_pos() == flower.pos:
                                    nectar = flower.give_nectar()
                                    if nectar > 0:
                                        a.nectar_collected += nectar
                                        print(f"{animal_type[:-1]} {a.ID} collected {nectar} nectar from flower at {flower.pos} at timestep {t}")
                                    else:
                                        print(f"{animal_type[:-1]} {a.ID} found no nectar at flower {flower.pos} at timestep {t}")
                        elif target in [tree.pos for tree in trees]:
                            for tree in trees:
                                if a.get_pos() == tree.pos:
                                    nectar = tree.give_nectar()
                                    if nectar > 0:
                                        a.nectar_collected += nectar
                                        print(f"{animal_type[:-1]} {a.ID} collected {nectar} nectar from tree at {tree.pos} at timestep {t}")
                                    else:
                                        print(f"{animal_type[:-1]} {a.ID} found no nectar at tree {tree.pos} at timestep {t}")
                        i += 1
                elif 0.5 * sim_length < t <= 0.6 * sim_length:  # Next 10% of the simulation
                    # Stage 4: Animals move randomly away from targets
                    if not a.get_inhive() and a.get_pos() == target and (i % 3 == 0 if t <= 0.55 * sim_length else i % 2 == 0):
                        a.move_out_of_tree(worldX, worldY)
                elif 0.6 * sim_length < t <= 0.75 * sim_length:  # Next 15% of the simulation
                    # Stage 5: Gradually return to hive
                    return_chance = (t - 0.6 * sim_length) / (0.15 * sim_length)
                    if not a.get_inhive() and random.random() < return_chance:
                        a.set_inhive(True)
                        a.pos = (np.random.randint(0, hiveX), np.random.randint(0, hiveY))
                elif 0.75 * sim_length < t <= 0.9 * sim_length:  # Next 15% of the simulation
                    # Stage 6: Random movement within the hive
                    if a.get_inhive():
                        a.pos = (np.random.randint(0, hiveX), np.random.randint(0, hiveY))
                else:  # Last 10% of the simulation
                    # Stage 7: Ensure all animals are in the hive
                    a.pos = (mid_x + random.choice([-1, 0, 1]), random.randint(0, hiveY))

                # Nectar check at current position
                nectar_found = False
                for flower in flowers:
                    if a.get_pos() == flower.pos:
                        nectar = flower.give_nectar()
                        if nectar > 0:
                            a.nectar_collected += nectar
                            nectar_found = True
                            print(f"{animal_type[:-1]} {a.ID} collected {nectar} nectar from flower at {flower.pos} at timestep {t}")
                for tree in trees:
                    if a.get_pos() == tree.pos:
                        nectar = tree.give_nectar()
                        if nectar > 0:
                            a.nectar_collected += nectar
                            nectar_found = True
                            print(f"{animal_type[:-1]} {a.ID} collected {nectar} nectar from tree at {tree.pos} at timestep {t}")
                if not nectar_found:
                    print(f"{animal_type[:-1]} {a.ID} at {a.get_pos()} found no flower or tree nectar at timestep {t}")
            except Exception as e:
                print(f"An error occurred during simulation: {e}")

        # Visualization step
        try:
            plot_hive(hive, alist, axes[0], t, mode)
            plot_world(world, alist, flowers, trees, axes[1], t, total_nectar_collected, mode)
            fig.suptitle(f"{animal_type} Hive and World Map - Timestep {t}")

            # Adjust plt.pause based on intensity
            if intensity == "heavy":
                plt.pause(0.3)  # Longer pause for heavy intensity
            elif intensity == "medium":
                plt.pause(0.2)  # Medium pause for medium intensity
            else:
                plt.pause(0.1)  # Short pause for light intensity
        except Exception as e:
            print(f"An error occurred during visualization: {e}")

    plt.ioff()
    plt.show()

    # Summary statistics
    print("\n=== Simulation Summary ===")
    print(f"Total Nectar Collected: {total_nectar_collected}")
    print(f"Intensity: {intensity}")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "-i":
        interactive_mode()
    elif len(sys.argv) == 3 and sys.argv[1] == "-p":
        para_path = sys.argv[2]
        try:
            name, animal_type, animal_count, flower_count, tree_count, mode, intensity, sim_length, timestamp = read_para_file(para_path)
            print(f"Map size: Time: {timestamp}")
            run_batch_simulation(name, animal_type, animal_count, flower_count, tree_count, mode, intensity, sim_length)
        except Exception as e:
            print(f"Error during batch simulation: {e}")
    else:
        print("Usage:")
        print("Interactive mode: python main.py -i")
        print("Batch mode: python main.py -p para.csv")
